## Install

Follow the generic plugin installation instructions in [the FIR wiki](https://github.com/certsocietegenerale/FIR/wiki/Plugins).

## Usage

The `fir_relations` plugin allows you to links incidents and events. The plugin parses incident descriptions and comments for incident references.

## Development

Everything you need to tweak the plugin is in the `fir_relations` directory: templates and actions (in `views.py`)
