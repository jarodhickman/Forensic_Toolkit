default_app_config = 'fir_notifications.apps.NotificationsConfig'
